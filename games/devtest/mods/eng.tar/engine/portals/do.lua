core.log("action", "Loading portals")
dofile(MineStars.ModPath.."/portals/API.lua")
dofile(MineStars.ModPath.."/portals/definitions.lua")
dofile(MineStars.ModPath.."/portals/heaven.lua")

