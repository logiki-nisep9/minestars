MineStars.Vanish = {
	Active = {},
}

local function update_visuals(name)
	local player = Player(name)
	if player then
		if MineStars.Vanish.Active[name] then
			player:set_properties({
				visual_size = vector.new(0,0,0),
				nametag = " ",
				pointable = false,
			})
		else
			player:set_properties({
				visual_size = vector.new(1,1,1),
				nametag = core.colorize(MineStars.Player.GetColor(name), name),
				pointable = true,
			})
		end
	end
end

core.register_chatcommand("vanish", {
	params = "",
	description = "Vanish",
	func = function(name)
		if Player(name) then
			if not MineStars.Vanish.Active[name] then
				MineStars.Vanish.Active[name] = true
				update_visuals(name)
				return true, core.colorize("lightgreen", C_..MineStars.Translator("Done!"))
			else
				MineStars.Vanish.Active[name] = nil
				update_visuals(name)
				return true, core.colorize("lightgreen", C_..MineStars.Translator("Done!"))
			end
		else
			return true, core.colorize("#FF7C7C", X..MineStars.Translator("Must be connected!"))
		end
	end,
})