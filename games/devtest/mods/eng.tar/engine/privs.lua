core.register_privilege("admin", {
	description = "Label for internal use"
})