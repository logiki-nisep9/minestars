--Shield [Likely from minecraft but applied here]

MineStars.Shield = {
	Huds = {},
	States = {},
}

function MineStars.Shield.HasShield(player)
	if Name(player) then
		local inv = minetest.get_inventory({type="detached", name=Name(player).."_armor"})
		--local inv = Inv(player)
		if not inv then
			return false
		end
		local list = inv:get_list("armor")
		for i, stack in pairs(list) do
			if stack:get_count() == 1 then
				local def = stack:get_definition()
				if def.groups and def.groups.armor_shield and def.groups.armor_shield > 0 then
					return true, stack
				end
			end
		end
	end
end

function MineStars.Shield.SetStateOfPlayer(player, state_bool)
	if state_bool then --enable shield
		if MineStars.Shield.HasShield(player) then
			MineStars.Physics.Set(player, {speed = 0.5, overrideother = true}, true, "FRAMEWORK_ENGINE:Shields", true) 
			RemovePrivs(player, {"interact"})
			local armor_groups = player:get_armor_groups()
			armor_groups.immortal = 1
			player:set_armor_groups(armor_groups)
			MineStars.Shield.States[Name(player)] = true
		end
	else
		MineStars.Physics.Remove(player, "FRAMEWORK_ENGINE:Shields")
		AddPrivs(player, {["interact"] = true})
		local armor_groups = player:get_armor_groups()
		armor_groups.immortal = 0
		player:set_armor_groups(armor_groups)
		MineStars.Shield.States[Name(player)] = false
	end
end

core.register_on_leaveplayer(function(player)
	MineStars.Shield.States[Name(player)] = nil
end)
